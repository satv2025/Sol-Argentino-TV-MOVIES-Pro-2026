import { supabase } from "./supabaseClient.js";

async function load() {
const { data } = await supabase.from("movies").select("*").limit(20);
const catalog = document.getElementById("catalog");
catalog.innerHTML = data.map(m => `
<div class="card">
<h3>${m.title}</h3>
<a href="/watch.html?movie=${m.id}">Ver</a>
</div>`).join("");
}
load();