import { buildMetaPills, cardHTML, episodeRowHTML } from "./templates.js";
import { pct, kindLabel, secondsToHM, escapeHtml, formatTE } from "./utils.js";

export function setActiveNav(route) {
  document.querySelectorAll(".nav__link").forEach(a => {
    a.classList.toggle("is-active", a.dataset.route === route);
  });
}

export function setRail(railEl, html) {
  railEl.innerHTML = html;
}

export function bindCardClicks(railEl, onOpen) {
  railEl.querySelectorAll(".card").forEach(card => {
    const open = () => onOpen(Number(card.dataset.titleId));
    card.addEventListener("click", open);
    card.addEventListener("keydown", (e) => {
      if (e.key === "Enter" || e.key === " ") open();
    });
  });
}

export function setHero({ title, progress }) {
  const heroBg = document.getElementById("heroBg");
  const heroTitle = document.getElementById("heroTitle");
  const heroMeta = document.getElementById("heroMeta");
  const heroOverview = document.getElementById("heroOverview");
  const heroResumeBtn = document.getElementById("heroResumeBtn");

  if (title?.backdrop_url) {
    heroBg.style.background =
      `linear-gradient(to top, rgba(7,7,11,.96), rgba(7,7,11,.55) 55%, rgba(7,7,11,.18)),
       url("${escapeHtml(title.backdrop_url)}") center/cover no-repeat`;
  } else {
    heroBg.style.background = "";
  }

  heroTitle.textContent = title?.title || "Sol Argentino TV MOVIES";
  heroMeta.innerHTML = title ? buildMetaPills(title) : "";
  heroOverview.textContent = title?.overview || "Tu plataforma para ver películas y series online.";

  heroResumeBtn.hidden = !Boolean(progress);
}

export function setDetailModal({ title, progress, inList }) {
  const titleEl = document.getElementById("detailTitle");
  const posterEl = document.getElementById("detailPoster");
  const metaEl = document.getElementById("detailMeta");
  const overviewEl = document.getElementById("detailOverview");

  const resumeBtn = document.getElementById("detailResumeBtn");
  const myListBtn = document.getElementById("detailMyListBtn");
  const progBox = document.getElementById("detailProgress");

  titleEl.textContent = title.title;
  overviewEl.textContent = title.overview ?? "";
  metaEl.innerHTML = buildMetaPills(title);

  if (title.poster_url) {
    posterEl.style.background = `linear-gradient(to top, rgba(0,0,0,.75), rgba(0,0,0,.20)), url("${escapeHtml(title.poster_url)}") center/cover no-repeat`;
  } else {
    posterEl.style.background = "";
  }

  resumeBtn.hidden = !Boolean(progress);

  const icon = myListBtn.querySelector("i");
  const text = myListBtn.querySelector("span");
  if (inList) {
    icon.className = "fa-solid fa-check";
    text.textContent = "En mi lista";
  } else {
    icon.className = "fa-solid fa-plus";
    text.textContent = "Mi lista";
  }

  if (progress) {
    const percentage = pct(progress.position_seconds, progress.duration_seconds);
    const te = formatTE(progress.season_number, progress.episode_number);
    const labelLeft = (title.kind === "series" && te) ? te : "Progreso";

    progBox.hidden = false;
    progBox.innerHTML = `
      <div style="display:flex;gap:10px;flex-wrap:wrap;align-items:center;justify-content:space-between;margin-bottom:10px;">
        <span class="meta-pill">${escapeHtml(kindLabel(title.kind))}</span>
        <span class="meta-pill">${escapeHtml(labelLeft)}</span>
        <span class="meta-pill">${Math.round(percentage)}%</span>
        <span class="meta-pill">${escapeHtml(secondsToHM(progress.position_seconds))} / ${escapeHtml(secondsToHM(progress.duration_seconds))}</span>
      </div>
      <div class="progress__bar"><div class="progress__fill" style="width:${percentage.toFixed(2)}%"></div></div>
    `;
  } else {
    progBox.hidden = true;
    progBox.innerHTML = "";
  }
}

export function renderCardsToRail({ railEl, titles, continueByTitleId }) {
  const html = titles
    .map(t => cardHTML({ title: t, progress: continueByTitleId?.get(t.id) ?? null }))
    .join("");
  setRail(railEl, html);
}

export function renderEpisodes({
  containerEl,
  episodes,
  progressByKey,
  thumbUrl,
}) {
  const html = episodes
    .map(ep => {
      const key = `${ep.season_number}:${ep.episode_number}`;
      const progress = progressByKey?.get(key) ?? null;
      return episodeRowHTML({ episode: ep, progress, thumbUrl });
    })
    .join("");

  containerEl.innerHTML = html;
}

export function toast(message) {
  const t = document.createElement("div");
  t.style.position = "fixed";
  t.style.left = "50%";
  t.style.bottom = "18px";
  t.style.transform = "translateX(-50%)";
  t.style.zIndex = "200";
  t.style.padding = "12px 14px";
  t.style.borderRadius = "999px";
  t.style.border = "1px solid rgba(255,255,255,.10)";
  t.style.background = "rgba(12,12,18,.88)";
  t.style.backdropFilter = "blur(10px)";
  t.style.color = "rgba(255,255,255,.92)";
  t.style.fontWeight = "900";
  t.style.fontSize = "12px";
  t.style.boxShadow = "0 20px 60px rgba(0,0,0,.55)";
  t.textContent = message;
  document.body.appendChild(t);
  setTimeout(() => t.remove(), 2200);
}
