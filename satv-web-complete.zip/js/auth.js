import { supabase } from './supabaseClient.js';

export async function getSession() {
  const { data } = await supabase.auth.getSession();
  return data.session;
}

export async function requireAuth() {
  const session = await getSession();
  if (!session) window.location.href = '/login.html';
  return session;
}

export async function login(email, password) {
  return await supabase.auth.signInWithPassword({ email, password });
}

export async function register(data) {
  return await supabase.auth.signUp({
    email: data.email,
    password: data.password,
    options: {
      data: {
        full_name: data.full_name,
        username: data.username,
        phone: data.phone
      }
    }
  });
}

export async function logout() {
  await supabase.auth.signOut();
}