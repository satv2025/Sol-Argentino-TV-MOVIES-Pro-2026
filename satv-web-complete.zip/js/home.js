import { getMovies } from './api.js';

async function init(){
  const movies = await getMovies();
  const catalog = document.getElementById('catalog');
  catalog.innerHTML = movies.map(m=>`
    <div class="card">
      <h3>${m.title}</h3>
      <a href="/watch.html?movie=${m.id}">Ver</a>
    </div>
  `).join('');
}

init();