import { getMovie, saveProgress } from './api.js';
import { requireAuth } from './auth.js';
import { supabase } from './supabaseClient.js';

function param(name){
  return new URL(window.location.href).searchParams.get(name);
}

async function init(){
  const session = await requireAuth();
  if(!session) return;

  const userId = session.user.id;
  const movieId = param('movie');
  const movie = await getMovie(movieId);

  const player = document.getElementById('player');
  player.src = movie.m3u8_url;

  player.addEventListener('time-update', async (e)=>{
    const seconds = Math.floor(e.detail.currentTime);
    await saveProgress(userId, movieId, seconds);
  });
}

init();