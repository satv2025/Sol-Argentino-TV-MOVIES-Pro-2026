import { supabase } from "./supabaseClient.js";

function getParam(name){
return new URL(window.location.href).searchParams.get(name);
}

async function init(){
const movieId = getParam("movie");
const { data: movie } = await supabase.from("movies").select("*").eq("id",movieId).single();
const player = document.getElementById("player");
player.src = movie.m3u8_url;

player.addEventListener("time-update", async (e)=>{
const time = Math.floor(e.detail.currentTime);
await supabase.from("watch_progress").upsert({
user_id:(await supabase.auth.getUser()).data.user.id,
movie_id:movieId,
progress_seconds:time
});
});
}
init();