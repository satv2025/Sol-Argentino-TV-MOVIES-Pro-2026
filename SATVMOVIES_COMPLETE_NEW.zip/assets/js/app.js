
async function loadMovies() {
  const res = await fetch('public/data/cardsData.json');
  const movies = await res.json();

  const app = document.getElementById('app');
  app.innerHTML = movies.map(m => `
    <div class="card">
      <h3>${m.title}</h3>
    </div>
  `).join('');
}

loadMovies();
