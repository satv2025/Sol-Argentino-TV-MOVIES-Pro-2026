import { renderNav, renderAuthButtons, toast, cardHtml, $, formatTime } from "./ui.js";
import { getSession } from "./auth.js";
import { fetchContinueWatching, fetchLatest, fetchByCategory } from "./api.js";
import { CONFIG } from "./config.js";

function setRow(el, html){ if (el) el.innerHTML = html; }

async function init(){
  renderNav({ active:"home" });
  await renderAuthButtons();

  const session = await getSession();
  const userId = session?.user?.id || null;

  // Continue watching
  const contWrap = $("#continue-wrap");
  const contRow = $("#continue-row");

  if (userId){
    try{
      const rows = await fetchContinueWatching(userId, 24);
      const cleaned = rows.filter(r => (r.progress_seconds || 0) >= 5);
      if (cleaned.length){
        contWrap.classList.remove("hidden");
        setRow(contRow, cleaned.map(r => {
          const m = r.movies;
          if (!m) return "";
          const ep = r.episodes || null;

          const href = ep
            ? `/watch.html?movie=${encodeURIComponent(m.id)}&episode=${encodeURIComponent(ep.id)}`
            : `/watch.html?movie=${encodeURIComponent(m.id)}`;

          const subtitle = ep
            ? `S${ep.season}E${ep.episode_number} · ${ep.title || ""} · ${formatTime(r.progress_seconds)}`
            : `Continuar · ${formatTime(r.progress_seconds)}`;

          // % not exact without duration; show pseudo progress bar scaled to 60min
          const pct = Math.min(98, Math.max(2, (r.progress_seconds % 3600) / 36));

          return cardHtml(m, href, subtitle, pct);
        }).join(""));
      } else {
        contWrap.classList.add("hidden");
      }
    }catch(e){
      console.error(e);
      contWrap.classList.add("hidden");
    }
  } else {
    contWrap.classList.add("hidden");
  }

  // Recommended (latest), movies, series
  try{
    const latest = await fetchLatest(24);
    setRow($("#latest-row"), latest.map(m => cardHtml(m)).join(""));

    const movies = await fetchByCategory("movie", 24);
    setRow($("#movies-row"), movies.map(m => cardHtml(m)).join(""));

    const series = await fetchByCategory("series", 24);
    setRow($("#series-row"), series.map(m => cardHtml(m)).join(""));
  }catch(e){
    console.error(e);
    toast("Error cargando catálogo. Revisá policies/RLS de movies/episodes.", "error");
  }
}

document.addEventListener("DOMContentLoaded", init);
