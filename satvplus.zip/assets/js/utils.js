export function escapeHtml(s) {
  return String(s ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

export function initialsFromName(name) {
  const n = String(name ?? "").trim();
  if (!n) return "U";
  const parts = n.split(/\s+/).slice(0, 2);
  return parts.map(p => (p[0] || "U").toUpperCase()).join("");
}

export function clamp(n, min, max) {
  return Math.min(max, Math.max(min, n));
}

export function pct(position, duration) {
  const d = Number(duration || 0);
  const p = Number(position || 0);
  if (d <= 0) return 0;
  return clamp((p / d) * 100, 0, 100);
}

export function secondsToHM(seconds) {
  const s = Math.max(0, Number(seconds || 0));
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  if (h > 0) return `${h} h ${m} min`;
  return `${m} min`;
}

export function kindLabel(kind) {
  return kind === "series" ? "Serie" : "Película";
}

export function stableSortByTitle(items) {
  return [...items].sort((a, b) => String(a.title).localeCompare(String(b.title)));
}

export function debounce(fn, wait = 250) {
  let t = null;
  return (...args) => {
    clearTimeout(t);
    t = setTimeout(() => fn(...args), wait);
  };
}

export function isHlsUrl(url) {
  return typeof url === "string" && url.toLowerCase().includes(".m3u8");
}

export function formatTE(seasonNumber, episodeNumber) {
  if (!seasonNumber || !episodeNumber) return "";
  return `T${seasonNumber} E${episodeNumber}`;
}
