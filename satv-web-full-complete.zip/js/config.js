// SATV config (public anon key is meant to be public)
export const CONFIG = {
  SUPABASE_URL: "REPLACE_WITH_YOUR_SUPABASE_URL",
  SUPABASE_ANON_KEY: "REPLACE_WITH_YOUR_SUPABASE_ANON_KEY",
  APP_NAME: "Sol Argentino TV MOVIES",
  // Optional: restrict Upload page to admins only (email match)
  ADMIN_EMAILS: [
    // "you@example.com"
  ],
  // Save progress throttle (ms)
  PROGRESS_THROTTLE_MS: 5000,
  // Consider as "watched" and hide from Continue Watching if near end (seconds)
  NEAR_END_SECONDS: 45
};