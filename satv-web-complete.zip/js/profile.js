import { requireAuth } from './auth.js';

async function init(){
  const session = await requireAuth();
  if(!session) return;

  document.getElementById('email').innerText = session.user.email;
}

init();