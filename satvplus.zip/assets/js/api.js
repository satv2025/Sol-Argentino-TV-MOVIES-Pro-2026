import { supabase } from "./supabaseClient.js";

// -------- AUTH --------
export async function getSession() {
  const { data, error } = await supabase.auth.getSession();
  if (error) throw error;
  return data.session;
}

export async function signIn(email, password) {
  const { data, error } = await supabase.auth.signInWithPassword({ email, password });
  if (error) throw error;
  return data.user;
}

export async function signUp(email, password) {
  const { data, error } = await supabase.auth.signUp({ email, password });
  if (error) throw error;
  return data.user;
}

export async function signOut() {
  const { error } = await supabase.auth.signOut();
  if (error) throw error;
}

// -------- CATALOG --------
export async function fetchCatalog({ q = "", kind = null, limit = 200 } = {}) {
  let query = supabase
    .from("titles")
    .select("id, slug, title, overview, kind, release_year, duration_seconds, total_seasons, total_episodes, poster_url, backdrop_url, created_at")
    .order("created_at", { ascending: false })
    .limit(limit);

  if (kind) query = query.eq("kind", kind);
  if (q?.trim()) query = query.ilike("title", `%${q.trim()}%`);

  const { data, error } = await query;
  if (error) throw error;
  return data ?? [];
}

// -------- EPISODES / SEASONS --------
export async function fetchSeasons(titleId) {
  const { data, error } = await supabase
    .from("seasons")
    .select("id, title_id, season_number, season_title")
    .eq("title_id", titleId)
    .order("season_number", { ascending: true });

  if (error) throw error;
  return data ?? [];
}

export async function fetchEpisodesBySeason(seasonId) {
  const { data, error } = await supabase
    .from("episodes")
    .select("id, title_id, season_id, episode_number, episode_title, duration_seconds")
    .eq("season_id", seasonId)
    .order("episode_number", { ascending: true });

  if (error) throw error;
  return data ?? [];
}

// -------- PROFILE --------
export async function fetchProfile(userId) {
  const { data, error } = await supabase
    .from("user_profiles")
    .select("user_id, username, display_name, avatar_url")
    .eq("user_id", userId)
    .maybeSingle();

  if (error) throw error;
  return data;
}

export async function upsertProfile(profile) {
  const { data: s } = await supabase.auth.getSession();
  const userId = s?.session?.user?.id;
  if (!userId) throw new Error("No authenticated");

  const row = {
    user_id: userId,
    display_name: profile.display_name ?? "",
    username: profile.username ?? null,
    avatar_url: profile.avatar_url ?? null,
  };

  const { error } = await supabase.from("user_profiles").upsert([row], { onConflict: "user_id" });
  if (error) throw error;
}

// -------- MY LIST --------
export async function fetchMyList(userId) {
  const { data, error } = await supabase
    .from("user_list")
    .select("created_at, titles:titles(id, slug, title, overview, kind, release_year, duration_seconds, total_seasons, total_episodes, poster_url, backdrop_url)")
    .eq("user_id", userId)
    .order("created_at", { ascending: false });

  if (error) throw error;
  return (data ?? []).map(r => r.titles).filter(Boolean);
}

export async function isInMyList(userId, titleId) {
  const { data, error } = await supabase
    .from("user_list")
    .select("title_id")
    .eq("user_id", userId)
    .eq("title_id", titleId)
    .maybeSingle();

  if (error) throw error;
  return Boolean(data);
}

export async function addToMyList(titleId) {
  const { data: s } = await supabase.auth.getSession();
  const userId = s?.session?.user?.id;
  if (!userId) throw new Error("No authenticated");

  const { error } = await supabase.from("user_list").insert([{ user_id: userId, title_id: titleId }]);
  if (error) throw error;
}

export async function removeFromMyList(titleId) {
  const { data: s } = await supabase.auth.getSession();
  const userId = s?.session?.user?.id;
  if (!userId) throw new Error("No authenticated");

  const { error } = await supabase.from("user_list").delete().eq("user_id", userId).eq("title_id", titleId);
  if (error) throw error;
}

// -------- PROGRESS --------
export async function fetchContinueWatching(userId, limit = 24) {
  const { data, error } = await supabase
    .from("user_progress")
    .select(`
      title_id,
      season_number,
      episode_number,
      position_seconds,
      duration_seconds,
      updated_at,
      titles:titles(id, slug, title, overview, kind, release_year, duration_seconds, total_seasons, total_episodes, poster_url, backdrop_url)
    `)
    .eq("user_id", userId)
    .order("updated_at", { ascending: false })
    .limit(limit);

  if (error) throw error;

  return (data ?? [])
    .map(r => ({ ...r, title: r.titles }))
    .filter(r => r.title);
}

export async function fetchProgressForTitleLatest(userId, titleId) {
  const { data, error } = await supabase
    .from("user_progress")
    .select("title_id, season_number, episode_number, position_seconds, duration_seconds, updated_at")
    .eq("user_id", userId)
    .eq("title_id", titleId)
    .order("updated_at", { ascending: false })
    .limit(1);

  if (error) throw error;
  return (data ?? [])[0] ?? null;
}

export async function fetchProgressForTitleAll(userId, titleId) {
  const { data, error } = await supabase
    .from("user_progress")
    .select("title_id, season_number, episode_number, position_seconds, duration_seconds, updated_at")
    .eq("user_id", userId)
    .eq("title_id", titleId)
    .order("updated_at", { ascending: false });

  if (error) throw error;
  return data ?? [];
}

export async function upsertProgress(payload) {
  const { data: s } = await supabase.auth.getSession();
  const userId = s?.session?.user?.id;
  if (!userId) throw new Error("No authenticated");

  const row = {
    user_id: userId,
    title_id: payload.title_id,
    season_number: payload.season_number ?? null,
    episode_number: payload.episode_number ?? null,
    position_seconds: payload.position_seconds ?? 0,
    duration_seconds: payload.duration_seconds ?? 0,
  };

  const { error } = await supabase
    .from("user_progress")
    .upsert([row], { onConflict: "user_id,title_id,season_number,episode_number" });

  if (error) throw error;
}

export async function deleteProgressForTitle(userId, titleId) {
  const { error } = await supabase
    .from("user_progress")
    .delete()
    .eq("user_id", userId)
    .eq("title_id", titleId);

  if (error) throw error;
}
