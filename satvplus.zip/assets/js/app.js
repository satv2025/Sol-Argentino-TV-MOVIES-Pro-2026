import { APP, image_map, media_map } from "./config.js";
import { supabase } from "./supabaseClient.js";
import {
  getSession, signIn, signUp, signOut,
  fetchCatalog, fetchProfile, upsertProfile,
  fetchMyList, isInMyList, addToMyList, removeFromMyList,
  fetchContinueWatching, fetchProgressForTitleLatest, fetchProgressForTitleAll, upsertProgress,
  fetchSeasons, fetchEpisodesBySeason,
} from "./api.js";
import { initialsFromName, debounce, isHlsUrl, formatTE } from "./utils.js";
import {
  setActiveNav, renderCardsToRail, bindCardClicks,
  setHero, setDetailModal, toast, renderEpisodes
} from "./ui.js";

const el = {
  authBtn: document.getElementById("authBtn"),
  profileBtn: document.getElementById("profileBtn"),
  profileInitials: document.getElementById("profileInitials"),
  profileAvatar: document.getElementById("profileAvatar"),

  authModal: document.getElementById("authModal"),
  detailModal: document.getElementById("detailModal"),
  playerModal: document.getElementById("playerModal"),

  logoutBtn: document.getElementById("logoutBtn"),

  loginForm: document.getElementById("loginForm"),
  signupForm: document.getElementById("signupForm"),
  profileForm: document.getElementById("profileForm"),

  loginHint: document.getElementById("loginHint"),
  signupHint: document.getElementById("signupHint"),
  profileHint: document.getElementById("profileHint"),

  profileTab: document.getElementById("profileTab"),
  tabs: Array.from(document.querySelectorAll(".tabs__tab")),

  searchInput: document.getElementById("searchInput"),
  catalogTitle: document.getElementById("catalogTitle"),

  continueRow: document.getElementById("continueRow"),
  myListRow: document.getElementById("myListRow"),
  continueRail: document.getElementById("continueRail"),
  myListRail: document.getElementById("myListRail"),
  catalogRail: document.getElementById("catalogRail"),

  scrollLeftBtn: document.getElementById("scrollLeftBtn"),
  scrollRightBtn: document.getElementById("scrollRightBtn"),

  heroPlayBtn: document.getElementById("heroPlayBtn"),
  heroResumeBtn: document.getElementById("heroResumeBtn"),
  heroMyListBtn: document.getElementById("heroMyListBtn"),
  heroInfoBtn: document.getElementById("heroInfoBtn"),

  detailPlayBtn: document.getElementById("detailPlayBtn"),
  detailResumeBtn: document.getElementById("detailResumeBtn"),
  detailMyListBtn: document.getElementById("detailMyListBtn"),

  detailEpisodes: document.getElementById("detailEpisodes"),
  seasonSelect: document.getElementById("seasonSelect"),
  episodesList: document.getElementById("episodesList"),

  playerTitle: document.getElementById("playerTitle"),
  playerSubtitle: document.getElementById("playerSubtitle"),
  playerNotice: document.getElementById("playerNotice"),
  videoEl: document.getElementById("videoEl"),
};

const state = {
  session: null,
  userId: null,
  profile: null,

  route: APP.defaultRoute,
  catalog: [],
  myList: [],
  continueRows: [],

  continueByTitleId: new Map(),

  heroTitle: null,
  heroProgress: null,

  detailTitle: null,
  detailProgressLatest: null,
  detailProgressAll: [],
  detailInList: false,

  seasons: [],
  episodes: [],
  activeSeasonId: null,

  hls: null,
  progressTimer: null,
  playingContext: null, // { titleId, seasonNumber, episodeNumber, durationSeconds }
};

function openModal(modalEl){ modalEl.hidden = false; document.body.style.overflow = "hidden"; }
function closeModal(modalEl){
  modalEl.hidden = true;
  if (el.authModal.hidden && el.detailModal.hidden && el.playerModal.hidden) {
    document.body.style.overflow = "";
  }
}
function setTab(tab) {
  el.tabs.forEach(t => t.classList.toggle("is-active", t.dataset.tab === tab));
  document.querySelectorAll(".form").forEach(f => f.classList.toggle("form--active", f.dataset.form === tab));
}
function currentKindFromRoute() {
  if (state.route === "movies") return "movie";
  if (state.route === "series") return "series";
  return null;
}

function applyImages(t) {
  const m = image_map?.[t.slug];
  return {
    ...t,
    poster_url: t.poster_url || m?.poster || null,
    backdrop_url: t.backdrop_url || m?.backdrop || m?.poster || null,
  };
}

function setAuthUI(isAuthed) {
  el.authBtn.hidden = isAuthed;
  el.profileBtn.hidden = !isAuthed;
  el.logoutBtn.hidden = !isAuthed;
  el.profileTab.hidden = !isAuthed;

  el.continueRow.hidden = !isAuthed;
  el.myListRow.hidden = !isAuthed;
}

async function refreshSession() {
  state.session = await getSession();
  state.userId = state.session?.user?.id ?? null;
  setAuthUI(Boolean(state.userId));

  if (state.userId) {
    state.profile = await fetchProfile(state.userId);
    const display = state.profile?.display_name || state.session.user.email || "U";

    const initials = initialsFromName(display);
    el.profileInitials.textContent = initials;

    // avatar
    const avatar = state.profile?.avatar_url || "";
    if (avatar) {
      el.profileAvatar.src = avatar;
      el.profileAvatar.hidden = false;
      el.profileInitials.hidden = true;
    }
  } else {
    state.profile = null;
    el.profileInitials.textContent = "U";
    el.profileAvatar.hidden = true;
    el.profileInitials.hidden = false;
  }

  // Profile form defaults
  if (state.userId) {
    el.profileForm.display_name.value = state.profile?.display_name ?? "";
    el.profileForm.username.value = state.profile?.username ?? "";
    el.profileForm.avatar_url.value = state.profile?.avatar_url ?? "";
  }
}

async function loadCatalog() {
  const kind = currentKindFromRoute();
  const q = el.searchInput.value || "";
  const list = await fetchCatalog({ q, kind, limit: APP.catalogLimit });
  state.catalog = list.map(applyImages);
}

async function loadAuthedData() {
  if (!state.userId) {
    state.myList = [];
    state.continueRows = [];
    state.continueByTitleId = new Map();
    return;
  }

  const [myList, cont] = await Promise.all([
    fetchMyList(state.userId),
    fetchContinueWatching(state.userId, APP.continueLimit),
  ]);

  state.myList = myList.map(applyImages);

  state.continueRows = cont.map(r => ({
    ...r,
    title: applyImages(r.title),
  }));

  // Map por title_id para mostrar progreso en cards
  const map = new Map();
  for (const row of state.continueRows) map.set(row.title_id, row);
  state.continueByTitleId = map;
}

function renderRails() {
  // Continue
  if (state.userId) {
    renderCardsToRail({
      railEl: el.continueRail,
      titles: state.continueRows.map(x => x.title),
      continueByTitleId: state.continueByTitleId,
    });
    bindCardClicks(el.continueRail, onOpenDetailById);

    // My List
    renderCardsToRail({ railEl: el.myListRail, titles: state.myList, continueByTitleId: state.continueByTitleId });
    bindCardClicks(el.myListRail, onOpenDetailById);
  }

  // Catalog (route aware)
  let list = state.catalog;
  if (state.route === "mylist") list = state.myList;

  renderCardsToRail({ railEl: el.catalogRail, titles: list, continueByTitleId: state.continueByTitleId });
  bindCardClicks(el.catalogRail, onOpenDetailById);
}

function setRoute(route) {
  state.route = route;
  setActiveNav(route);

  if (route === "mylist") el.catalogTitle.textContent = "Mi lista";
  else if (route === "movies") el.catalogTitle.textContent = "Películas";
  else if (route === "series") el.catalogTitle.textContent = "Series";
  else el.catalogTitle.textContent = "Catálogo";
}

function pickHero() {
  if (!state.catalog.length) return null;
  if (APP.heroPick === "random") return state.catalog[Math.floor(Math.random() * state.catalog.length)];
  if (APP.heroPick && APP.heroPick !== "latest") {
    const bySlug = state.catalog.find(x => x.slug === APP.heroPick);
    if (bySlug) return bySlug;
  }
  return state.catalog[0];
}

async function refreshHero() {
  const title = pickHero();
  state.heroTitle = title;

  if (!title) {
    setHero({ title: null, progress: null });
    return;
  }

  if (state.userId) {
    state.heroProgress = await fetchProgressForTitleLatest(state.userId, title.id);
  } else {
    state.heroProgress = null;
  }

  setHero({ title, progress: state.heroProgress });
  await syncHeroMyListButton();
}

async function syncHeroMyListButton() {
  const btn = el.heroMyListBtn;
  const icon = btn.querySelector("i");
  const text = btn.querySelector("span");

  if (!state.userId || !state.heroTitle) {
    icon.className = "fa-solid fa-plus";
    text.textContent = "Mi lista";
    return;
  }

  const inList = state.myList.some(x => x.id === state.heroTitle.id);
  icon.className = inList ? "fa-solid fa-check" : "fa-solid fa-plus";
  text.textContent = inList ? "En mi lista" : "Mi lista";
}

async function onOpenDetailById(titleId) {
  const title = state.catalog.find(x => x.id === titleId) || state.myList.find(x => x.id === titleId);
  if (!title) return;

  state.detailTitle = title;

  // Load progress + list status
  if (state.userId) {
    const [latest, all, inList] = await Promise.all([
      fetchProgressForTitleLatest(state.userId, title.id),
      fetchProgressForTitleAll(state.userId, title.id),
      isInMyList(state.userId, title.id),
    ]);
    state.detailProgressLatest = latest;
    state.detailProgressAll = all;
    state.detailInList = inList;
  } else {
    state.detailProgressLatest = null;
    state.detailProgressAll = [];
    state.detailInList = false;
  }

  setDetailModal({ title, progress: state.detailProgressLatest, inList: state.detailInList });

  // Series: seasons/episodes
  await loadSeriesDetailIfNeeded();

  openModal(el.detailModal);
}

function openAuth() { openModal(el.authModal); setTab("login"); }

async function toggleMyListForTitle(title) {
  if (!state.userId) return openAuth();

  const inList = state.myList.some(x => x.id === title.id);
  if (inList) await removeFromMyList(title.id);
  else await addToMyList(title.id);

  await loadAuthedData();
  renderRails();
  await syncHeroMyListButton();

  // if detail is open
  if (state.detailTitle?.id === title.id) {
    state.detailInList = !inList;
    setDetailModal({ title: state.detailTitle, progress: state.detailProgressLatest, inList: state.detailInList });
  }

  toast(inList ? "Quitado de Mi lista" : "Agregado a Mi lista");
}

async function ensureProfileAfterSignup(fd) {
  // profile table requires authenticated session; depending on Supabase email confirmation settings,
  // session may exist immediately or after confirmation. We'll attempt upsert; if fails, user can update later.
  try {
    await upsertProfile({
      display_name: fd.get("display_name"),
      username: fd.get("username"),
      avatar_url: null,
    });
  } catch (e) {
    // no throw; profile can be edited later
  }
}

function getMediaForTitle(title) {
  const entry = media_map?.[title.slug];
  if (!entry || !entry.url) return null;
  const type = entry.type || (isHlsUrl(entry.url) ? "hls" : "mp4");
  return { url: entry.url, type };
}

function setPlayerNotice(msg) {
  el.playerNotice.hidden = !msg;
  el.playerNotice.textContent = msg || "";
}

function destroyHls() {
  if (state.hls) {
    try { state.hls.destroy(); } catch {}
    state.hls = null;
  }
}

function stopProgressTimer() {
  if (state.progressTimer) {
    clearInterval(state.progressTimer);
    state.progressTimer = null;
  }
}

async function persistProgressFromVideo(force = false) {
  if (!state.userId || !state.playingContext) return;

  const v = el.videoEl;
  const duration = Number.isFinite(v.duration) ? Math.floor(v.duration) : (state.playingContext.durationSeconds ?? 0);
  const position = Math.floor(v.currentTime || 0);

  if (!force && position < APP.minSecondsToSave) return;

  await upsertProgress({
    title_id: state.playingContext.titleId,
    season_number: state.playingContext.seasonNumber ?? null,
    episode_number: state.playingContext.episodeNumber ?? null,
    position_seconds: position,
    duration_seconds: duration,
  });

  // refresh continue / hero / detail UI
  await loadAuthedData();
  renderRails();

  if (state.heroTitle?.id === state.playingContext.titleId) {
    state.heroProgress = await fetchProgressForTitleLatest(state.userId, state.playingContext.titleId);
    setHero({ title: state.heroTitle, progress: state.heroProgress });
  }

  if (state.detailTitle?.id === state.playingContext.titleId) {
    state.detailProgressLatest = await fetchProgressForTitleLatest(state.userId, state.playingContext.titleId);
    setDetailModal({ title: state.detailTitle, progress: state.detailProgressLatest, inList: state.detailInList });
  }
}

async function openPlayerFor({
  title,
  seasonNumber = null,
  episodeNumber = null,
  resumeAtSeconds = 0,
}) {
  if (!state.userId) return openAuth();

  const media = getMediaForTitle(title);
  el.playerTitle.textContent = title.title;
  el.playerSubtitle.textContent = (title.kind === "series" && seasonNumber && episodeNumber)
    ? formatTE(seasonNumber, episodeNumber)
    : (title.kind === "movie" ? "Película" : "Serie");

  destroyHls();
  stopProgressTimer();

  el.videoEl.pause();
  el.videoEl.removeAttribute("src");
  el.videoEl.load();

  if (!media) {
    setPlayerNotice("Este título aún no tiene URL de reproducción configurada. Configuralo en assets/js/config.js (media_map).");
    openModal(el.playerModal);
    return;
  }

  setPlayerNotice("");

  // Set context for progress persistence
  state.playingContext = {
    titleId: title.id,
    seasonNumber,
    episodeNumber,
    durationSeconds: title.duration_seconds ?? 0,
  };

  if (media.type === "hls") {
    if (window.Hls && window.Hls.isSupported()) {
      state.hls = new window.Hls({ enableWorker: true, lowLatencyMode: true });
      state.hls.loadSource(media.url);
      state.hls.attachMedia(el.videoEl);
    } else {
      // Safari supports HLS natively
      el.videoEl.src = media.url;
    }
  } else {
    el.videoEl.src = media.url;
  }

  openModal(el.playerModal);

  // Resume
  el.videoEl.currentTime = Math.max(0, Number(resumeAtSeconds || 0));
  try { await el.videoEl.play(); } catch {}

  // Save progress interval
  state.progressTimer = setInterval(() => {
    persistProgressFromVideo(false).catch(() => {});
  }, APP.progressSaveIntervalSeconds * 1000);
}

async function loadSeriesDetailIfNeeded() {
  const title = state.detailTitle;
  if (!title || title.kind !== "series") {
    el.detailEpisodes.hidden = true;
    return;
  }

  el.detailEpisodes.hidden = false;

  state.seasons = await fetchSeasons(title.id);
  if (!state.seasons.length) {
    // If seasons aren't seeded, hide list
    el.detailEpisodes.hidden = true;
    return;
  }

  // Build select
  el.seasonSelect.innerHTML = "";
  for (const s of state.seasons) {
    const opt = document.createElement("option");
    opt.value = String(s.id);
    opt.textContent = s.season_title || `Temporada ${s.season_number}`;
    el.seasonSelect.appendChild(opt);
  }

  // default active season = first
  state.activeSeasonId = state.seasons[0].id;
  el.seasonSelect.value = String(state.activeSeasonId);

  await loadEpisodesForActiveSeason();
}

async function loadEpisodesForActiveSeason() {
  const title = state.detailTitle;
  if (!title || title.kind !== "series" || !state.activeSeasonId) return;

  const season = state.seasons.find(s => s.id === state.activeSeasonId);
  const seasonNumber = season?.season_number ?? 1;

  const episodes = await fetchEpisodesBySeason(state.activeSeasonId);
  state.episodes = episodes.map(ep => ({
    ...ep,
    season_number: seasonNumber,
    episode_number: ep.episode_number,
  }));

  // Map progress by season:episode
  const progressByKey = new Map();
  for (const p of state.detailProgressAll ?? []) {
    const key = `${p.season_number}:${p.episode_number}`;
    progressByKey.set(key, p);
  }

  renderEpisodes({
    containerEl: el.episodesList,
    episodes: state.episodes,
    progressByKey,
    thumbUrl: title.backdrop_url || title.poster_url || "",
  });

  // Bind episode buttons
  el.episodesList.querySelectorAll("[data-action='play-episode']").forEach(btn => {
    btn.addEventListener("click", async () => {
      const s = Number(btn.dataset.season);
      const e = Number(btn.dataset.episode);
      await openPlayerFor({ title, seasonNumber: s, episodeNumber: e, resumeAtSeconds: 0 });
    });
  });

  el.episodesList.querySelectorAll("[data-action='resume-episode']").forEach(btn => {
    btn.addEventListener("click", async () => {
      const s = Number(btn.dataset.season);
      const e = Number(btn.dataset.episode);
      const key = `${s}:${e}`;
      const p = progressByKey.get(key);
      await openPlayerFor({ title, seasonNumber: s, episodeNumber: e, resumeAtSeconds: p?.position_seconds ?? 0 });
    });
  });
}

function bindEvents() {
  // Close modals
  document.querySelectorAll("[data-close]").forEach(x => {
    x.addEventListener("click", () => {
      const which = x.dataset.close;
      if (which === "auth") closeModal(el.authModal);
      if (which === "detail") closeModal(el.detailModal);
      if (which === "player") closePlayer();
    });
  });

  // Escape to close
  window.addEventListener("keydown", (e) => {
    if (e.key !== "Escape") return;
    if (!el.playerModal.hidden) closePlayer();
    else if (!el.detailModal.hidden) closeModal(el.detailModal);
    else if (!el.authModal.hidden) closeModal(el.authModal);
  });

  // Nav
  document.querySelectorAll("[data-route]").forEach(a => {
    a.addEventListener("click", async (e) => {
      e.preventDefault();
      const route = a.dataset.route;
      setRoute(route);
      await loadCatalog();
      await refreshHero();
      renderRails();
      window.scrollTo({ top: 0, behavior: "smooth" });
    });
  });

  // Auth open
  el.authBtn.addEventListener("click", openAuth);
  el.profileBtn.addEventListener("click", () => { openModal(el.authModal); setTab("profile"); });

  // Tabs
  el.tabs.forEach(t => t.addEventListener("click", () => setTab(t.dataset.tab)));

  // Search
  el.searchInput.addEventListener("input", debounce(async () => {
    await loadCatalog();
    await refreshHero();
    renderRails();
  }, 200));

  // Scroll arrows for catalog rail
  el.scrollLeftBtn.addEventListener("click", () => el.catalogRail.scrollBy({ left: -720, behavior: "smooth" }));
  el.scrollRightBtn.addEventListener("click", () => el.catalogRail.scrollBy({ left: 720, behavior: "smooth" }));

  // Auth forms
  el.loginForm.addEventListener("submit", async (e) => {
    e.preventDefault();
    el.loginHint.textContent = "";
    const fd = new FormData(e.currentTarget);

    try {
      await signIn(fd.get("email"), fd.get("password"));
      closeModal(el.authModal);
      toast("Sesión iniciada");
    } catch (err) {
      el.loginHint.textContent = String(err?.message || err);
    }
  });

  el.signupForm.addEventListener("submit", async (e) => {
    e.preventDefault();
    el.signupHint.textContent = "";
    const fd = new FormData(e.currentTarget);

    try {
      await signUp(fd.get("email"), fd.get("password"));
      await refreshSession();
      await ensureProfileAfterSignup(fd);
      el.signupHint.textContent = "Cuenta creada. Si tu proyecto requiere confirmación por email, revisá tu casilla.";
      setTab("login");
    } catch (err) {
      el.signupHint.textContent = String(err?.message || err);
    }
  });

  el.profileForm.addEventListener("submit", async (e) => {
    e.preventDefault();
    el.profileHint.textContent = "";

    try {
      await upsertProfile({
        display_name: el.profileForm.display_name.value,
        username: el.profileForm.username.value,
        avatar_url: el.profileForm.avatar_url.value || null,
      });

      await refreshSession();
      el.profileHint.textContent = "Perfil actualizado.";
      toast("Perfil actualizado");
    } catch (err) {
      el.profileHint.textContent = String(err?.message || err);
    }
  });

  el.logoutBtn.addEventListener("click", async () => {
    await signOut();
    closeModal(el.authModal);
    toast("Sesión cerrada");
  });

  // Hero actions
  el.heroPlayBtn.addEventListener("click", async () => {
    if (!state.heroTitle) return;
    if (state.heroTitle.kind === "series") {
      // default: T1 E1
      await openPlayerFor({ title: state.heroTitle, seasonNumber: 1, episodeNumber: 1, resumeAtSeconds: 0 });
    } else {
      await openPlayerFor({ title: state.heroTitle, resumeAtSeconds: 0 });
    }
  });

  el.heroResumeBtn.addEventListener("click", async () => {
    if (!state.heroTitle || !state.heroProgress) return;
    const p = state.heroProgress;
    await openPlayerFor({
      title: state.heroTitle,
      seasonNumber: p.season_number ?? null,
      episodeNumber: p.episode_number ?? null,
      resumeAtSeconds: p.position_seconds ?? 0,
    });
  });

  el.heroMyListBtn.addEventListener("click", async () => {
    if (!state.heroTitle) return;
    await toggleMyListForTitle(state.heroTitle);
  });

  el.heroInfoBtn.addEventListener("click", async () => {
    if (!state.heroTitle) return;
    await onOpenDetailById(state.heroTitle.id);
  });

  // Detail actions
  el.detailPlayBtn.addEventListener("click", async () => {
    if (!state.detailTitle) return;
    if (state.detailTitle.kind === "series") {
      await openPlayerFor({ title: state.detailTitle, seasonNumber: 1, episodeNumber: 1, resumeAtSeconds: 0 });
    } else {
      await openPlayerFor({ title: state.detailTitle, resumeAtSeconds: 0 });
    }
  });

  el.detailResumeBtn.addEventListener("click", async () => {
    if (!state.detailTitle || !state.detailProgressLatest) return;
    const p = state.detailProgressLatest;
    await openPlayerFor({
      title: state.detailTitle,
      seasonNumber: p.season_number ?? null,
      episodeNumber: p.episode_number ?? null,
      resumeAtSeconds: p.position_seconds ?? 0,
    });
  });

  el.detailMyListBtn.addEventListener("click", async () => {
    if (!state.detailTitle) return;
    await toggleMyListForTitle(state.detailTitle);
  });

  el.seasonSelect.addEventListener("change", async () => {
    state.activeSeasonId = Number(el.seasonSelect.value);
    await loadEpisodesForActiveSeason();
  });

  // Player events
  el.videoEl.addEventListener("pause", () => { persistProgressFromVideo(true).catch(() => {}); });
  el.videoEl.addEventListener("ended", () => { persistProgressFromVideo(true).catch(() => {}); });
}

function closePlayer() {
  stopProgressTimer();
  destroyHls();
  state.playingContext = null;

  try { el.videoEl.pause(); } catch {}
  el.videoEl.removeAttribute("src");
  el.videoEl.load();

  closeModal(el.playerModal);
}

async function boot() {
  bindEvents();
  setRoute(APP.defaultRoute);

  // Fix: avatar rendering
  el.profileAvatar.hidden = true;
  el.profileInitials.hidden = false;

  // Auth state change
  supabase.auth.onAuthStateChange(async () => {
    await refreshSession();
    await loadCatalog();
    await loadAuthedData();
    await refreshHero();
    renderRails();
  });

  await refreshSession();
  await loadCatalog();
  await loadAuthedData();
  await refreshHero();
  renderRails();
}

boot().catch((e) => {
  console.error(e);
  toast("Error inicializando la app. Revisá consola.");
});
