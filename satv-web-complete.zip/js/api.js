import { supabase } from './supabaseClient.js';

export async function getMovies() {
  const { data } = await supabase.from('movies').select('*').order('created_at', { ascending: false });
  return data || [];
}

export async function getMovie(id) {
  const { data } = await supabase.from('movies').select('*').eq('id', id).single();
  return data;
}

export async function saveProgress(userId, movieId, seconds) {
  return await supabase.from('watch_progress').upsert({
    user_id: userId,
    movie_id: movieId,
    progress_seconds: seconds,
    updated_at: new Date().toISOString()
  }, { onConflict: 'user_id,movie_id' });
}