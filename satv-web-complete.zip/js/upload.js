import { supabase } from './supabaseClient.js';
import { requireAuth } from './auth.js';

async function init(){
  await requireAuth();

  document.getElementById('upload-form').addEventListener('submit', async e=>{
    e.preventDefault();
    const title = document.getElementById('title').value;
    const m3u8 = document.getElementById('m3u8').value;

    await supabase.from('movies').insert({
      title,
      m3u8_url: m3u8,
      category: 'movie'
    });

    alert('Contenido cargado');
  });
}

init();