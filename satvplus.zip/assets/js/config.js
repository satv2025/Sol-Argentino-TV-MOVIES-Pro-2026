// SATV+ Frontend Config
// Catálogo: se lee desde Supabase (tabla public.titles) según el SQL provisto.
// Imágenes: el SQL no incluye poster/backdrop, por eso se resuelven por slug acá.
//
// Para configurar reproducción real por título, agregá media_map (HLS .m3u8 o MP4).
// Ejemplo:
// media_map: { "matias-ponce-la-pelicula": { url:"https://.../master.m3u8", type:"hls" } }

export const APP = {
  appName: "Sol Argentino TV MOVIES",
  brand: "SATV",
  subBrand: "MOVIES",
  defaultRoute: "home",
  heroPick: "latest", // "latest" | "random" | slug
  continueLimit: 24,
  catalogLimit: 200,
  progressSaveIntervalSeconds: 10, // guardado de progreso mientras reproduce
  minSecondsToSave: 5, // evita writes por arranque inmediato
};

export const image_map = {
  "matias-ponce-la-pelicula": {
    poster: "https://old.movies.solargentinotv.com.ar/assets/media/images/mpthumb.jpg",
    backdrop: "https://old.movies.solargentinotv.com.ar/assets/media/images/mpthumb.jpg",
  },
  "100-lucha-la-pelicula": {
    poster: "https://old.movies.solargentinotv.com.ar/assets/media/images/100luchathumb.jpg",
    backdrop: "https://old.movies.solargentinotv.com.ar/assets/media/images/100luchathumb.jpg",
  },
  "100-lucha-el-amo-de-los-clones": {
    poster: "https://media.minutouno.com/p/8f27c301f5e629ec8dab0477e7a75ae0/adjuntos/150/imagenes/026/947/0026947782/1200x675/smart/lucha.png",
    backdrop: "https://media.minutouno.com/p/8f27c301f5e629ec8dab0477e7a75ae0/adjuntos/150/imagenes/026/947/0026947782/1200x675/smart/lucha.png",
  },
  "mi-pobre-angelito": {
    poster: "https://disney.images.edge.bamgrid.com/ripcut-delivery/v2/variant/disney/a3242080-601c-488b-afd2-1f9bed5f5d99/compose",
    backdrop: "https://disney.images.edge.bamgrid.com/ripcut-delivery/v2/variant/disney/a3242080-601c-488b-afd2-1f9bed5f5d99/compose",
  },
  "mi-pobre-angelito-2": {
    poster: "https://disney.images.edge.bamgrid.com/ripcut-delivery/v2/variant/disney/5046911a-aaf2-4d52-8127-438643a35b24/compose",
    backdrop: "https://disney.images.edge.bamgrid.com/ripcut-delivery/v2/variant/disney/5046911a-aaf2-4d52-8127-438643a35b24/compose",
  },
  "fears-to-fathom-norwood-hitchhike": {
    poster: "https://shared.fastly.steamstatic.com/store_item_assets/steam/apps/1763050/capsule_616x353.jpg",
    backdrop: "https://shared.fastly.steamstatic.com/store_item_assets/steam/apps/1763050/capsule_616x353.jpg",
  },
  "asesinato-para-principiantes": {
    poster: "https://old.movies.solargentinotv.com.ar/assets/media/images/appthumb.webp",
    backdrop: "https://old.movies.solargentinotv.com.ar/assets/media/images/appthumb.webp",
  },
  "nivel-x": {
    poster: "assets/media/images/nivelxthumbcard.jpg",
    backdrop: "assets/media/images/nivelxthumbcard.jpg",
  },
  "reite666": {
    poster: "https://old.movies.solargentinotv.com.ar/assets/media/images/Logo%20Reite666%202.png",
    backdrop: "https://old.movies.solargentinotv.com.ar/assets/media/images/Logo%20Reite666%202.png",
  },
  "las-cajas-misteriosas": {
    poster: "assets/media/images/las-cajas-misteriosas.svg",
    backdrop: "assets/media/images/las-cajas-misteriosas.svg",
  },
};

export const media_map = {
  // slug: { url: "https://...", type: "hls" | "mp4" }
};
