import { escapeHtml, kindLabel, secondsToHM, pct, formatTE } from "./utils.js";

export function buildMetaPills(t) {
  const pills = [];
  if (t.kind) pills.push(`<span class="meta-pill">${escapeHtml(kindLabel(t.kind))}</span>`);
  if (t.release_year) pills.push(`<span class="meta-pill">${escapeHtml(String(t.release_year))}</span>`);

  if (t.kind === "movie" && t.duration_seconds) {
    pills.push(`<span class="meta-pill">${escapeHtml(secondsToHM(t.duration_seconds))}</span>`);
  }

  if (t.kind === "series" && t.total_seasons) {
    pills.push(`<span class="meta-pill">${escapeHtml(String(t.total_seasons))} temporadas</span>`);
  }

  if (t.kind === "series" && t.total_episodes) {
    pills.push(`<span class="meta-pill">${escapeHtml(String(t.total_episodes))} episodios</span>`);
  }

  return pills.join("");
}

export function cardHTML({ title, progress }) {
  const posterStyle = title.poster_url
    ? `style="background-image:linear-gradient(to top, rgba(0,0,0,.72), rgba(0,0,0,.18)), url('${escapeHtml(title.poster_url)}');"`
    : "";

  const leftMeta = title.release_year ? String(title.release_year) : "";
  const pill = kindLabel(title.kind);

  let progressHTML = "";
  if (progress) {
    const percentage = pct(progress.position_seconds, progress.duration_seconds);
    const te = formatTE(progress.season_number, progress.episode_number);
    const labelLeft = (title.kind === "series" && te) ? te : "Progreso";

    progressHTML = `
      <div class="progress">
        <div class="progress__bar"><div class="progress__fill" style="width:${percentage.toFixed(2)}%"></div></div>
        <div class="progress__label"><span>${escapeHtml(labelLeft)}</span><span>${Math.round(percentage)}%</span></div>
      </div>
    `;
  }

  return `
    <div class="card" role="button" tabindex="0" data-title-id="${escapeHtml(String(title.id))}">
      <div class="card__poster" ${posterStyle}>
        <div class="card__posterTitle">${escapeHtml(title.title)}</div>
      </div>
      <div class="card__body">
        <div class="card__meta">
          <span>${escapeHtml(leftMeta)}</span>
          <span class="pill">${escapeHtml(pill)}</span>
        </div>
        ${progressHTML}
      </div>
    </div>
  `;
}

export function episodeRowHTML({ episode, progress, thumbUrl }) {
  const te = formatTE(episode.season_number, episode.episode_number);
  const percentage = progress ? pct(progress.position_seconds, progress.duration_seconds) : 0;

  const thumbStyle = thumbUrl
    ? `style="background-image:linear-gradient(to top, rgba(0,0,0,.55), rgba(0,0,0,.15)), url('${escapeHtml(thumbUrl)}');"`
    : "";

  const progressPill = progress ? `<span class="meta-pill">${Math.round(percentage)}%</span>` : "";

  return `
    <div class="episode" data-episode-id="${escapeHtml(String(episode.id))}">
      <div class="episode__thumb" ${thumbStyle}></div>
      <div class="episode__info">
        <div class="episode__top">
          <div class="episode__title">${escapeHtml(te)} · ${escapeHtml(episode.episode_title ?? ("Episodio " + episode.episode_number))}</div>
          <div class="episode__meta">
            ${progressPill}
          </div>
        </div>

        ${progress ? `
          <div class="progress">
            <div class="progress__bar"><div class="progress__fill" style="width:${percentage.toFixed(2)}%"></div></div>
            <div class="progress__label"><span>Progreso</span><span>${Math.round(percentage)}%</span></div>
          </div>
        ` : ""}

        <div class="episode__actions">
          <button class="btn btn--secondary" type="button" data-action="play-episode" data-season="${escapeHtml(String(episode.season_number))}" data-episode="${escapeHtml(String(episode.episode_number))}">
            <i class="fa-solid fa-play" aria-hidden="true"></i>
            <span>Reproducir</span>
          </button>

          ${progress ? `
            <button class="btn btn--ghost" type="button" data-action="resume-episode" data-season="${escapeHtml(String(episode.season_number))}" data-episode="${escapeHtml(String(episode.episode_number))}">
              <i class="fa-solid fa-rotate-right" aria-hidden="true"></i>
              <span>Continuar</span>
            </button>
          ` : ""}
        </div>
      </div>
    </div>
  `;
}
