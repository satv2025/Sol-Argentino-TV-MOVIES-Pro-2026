export function qs(q){ return document.querySelector(q); }

export function toast(msg){
  const host = document.getElementById('toast-host');
  if(!host) return alert(msg);
  const div = document.createElement('div');
  div.className = 'toast';
  div.innerText = msg;
  host.appendChild(div);
  setTimeout(()=> div.remove(), 3000);
}